% Experiment 1 - Energy Balance Model - Global Ice Cover
par.model_to_run='2d-sphere';
par.version = '1d-sphere-global';
par.Ta_surface_profile_type = 'cold';
par.Hcr = 10;
% Hcr should be between Hcr_max and min(h) - see update_Hcr
par.Sedge = 0;
par.Nedge = 0;
