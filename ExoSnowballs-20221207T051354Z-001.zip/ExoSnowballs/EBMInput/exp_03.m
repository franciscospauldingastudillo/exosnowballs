% Experiment 2 - Energy Balance Model - Ice Free 
par.model_to_run='2d-sphere';
par.version = '1d-sphere-icefree';
par.Ta_surface_profile_type = 'cold';
par.Hcr = 1;
%par.Nedge = 8;
%par.Sedge = par.nj-7;
%par.Nedge = NaN;
%par.Sedge = NaN;
par.Nedge = 13;
par.Sedge = par.nj-12;

