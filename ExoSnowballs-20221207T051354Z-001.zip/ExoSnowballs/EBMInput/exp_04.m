% Experiment 2 - Energy Balance Model - Modern Earth  
par.model_to_run='2d-sphere';
par.version = '1d-sphere-modern';
par.Nedge = 12; 
par.Sedge = 78;
par.Ta_surface_profile_type = 'cold';
par.Hcr = 1; % critical thickness, meters
